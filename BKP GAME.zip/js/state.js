// 1.1. ELEMENTOS DO DOM
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const vidasContainerEsquerda = document.getElementById("vidasContainerEsquerda");
const vidasContainerDireita = document.getElementById("vidasContainerDireita");
const nivelDisplay = document.getElementById("nivelDisplay");
const xpBar = document.getElementById("xpBar");
const btnReiniciarNivel = document.getElementById("btnReiniciarNivel");
const telaInicial = document.getElementById("telaInicial");
const telaFinal = document.getElementById("telaFinal");
const btnJogar = document.getElementById("btnJogar");
const btnJogarNovamente = document.getElementById("btnJogarNovamente");
const tituloFinal = document.getElementById("tituloFinal");
const mensagemFinal = document.getElementById("mensagemFinal");

// 1.3. ESTADO DO JOGO (gameState)
let gameState = {
    jogoRodando: false,
    nivelAtual: 1,
    numMortes: 0,
    vidas: CONFIG.MAX_VIDAS,
    mapa: [],
    chavesColetadas: 0,
    framesDesdeInicio: 0,
    framesDesdeRespawn: 0,
    portalCooldown: 0,
};

// 1.4. DADOS DO PERSONAGEM
let personagem = {
    nick: "",
    cor: "#a7d1fa",
    efeitos: ["nenhum"],
    opacidade: 1.0,
};

// 1.5. JOGADOR (jogador)
let jogador = {
    x: CONFIG.LARGURA_BLOCO * 2,
    y: CONFIG.CHAO_Y - CONFIG.LARGURA_BLOCO * 3,
    largura: CONFIG.PLAYER_LARGURA,
    altura: CONFIG.PLAYER_ALTURA,
    raio: CONFIG.PLAYER_RAIO,
    velocidadeX: 0,
    velocidadeY: 0,
    saltosRestantes: CONFIG.MAX_JUMPS,
    noChao: false,
    pulando: false,
    rastro: [],
};

// 1.6. ELEMENTOS DE CENÁRIO (estrelas, partículas)
let estrelasPerto = Array.from({ length: CONFIG.NUM_ESTRELAS_PERTO }, () => ({
    x: Math.random() * CONFIG.CANVAS_LARGURA,
    y: Math.random() * CONFIG.CANVAS_ALTURA * 0.7,
    raio: Math.random() * 1.8 + 0.5,
    opacidade: Math.random() * 0.5 + 0.5,
}));
let estrelasLonge = Array.from({ length: CONFIG.NUM_ESTRELAS_LONGE }, () => ({
    x: Math.random() * CONFIG.CANVAS_LARGURA,
    y: Math.random() * CONFIG.CANVAS_ALTURA * 0.7,
    raio: Math.random() * 1.2 + 0.3,
    opacidade: Math.random() * 0.3 + 0.2,
}));
let particulas = [];

// 1.7. CONTROLES (teclas)
const teclas = {};
document.addEventListener("keydown", (e) => (teclas[e.key.toLowerCase()] = true));
document.addEventListener("keyup", (e) => (teclas[e.key.toLowerCase()] = false));
