const EFEITOS = {
    'nenhum': { nome: "Nenhum", emoji: "🚫", update: () => { } },
    'cinzas': {
        nome: "Cinzas", emoji: "🔥",
        update: (ctx, cx, cy, p, gs, j, criar) => {
            if (gs.framesDesdeInicio % 5 === 0) {
                const corInicial = '255,100,0'; // Laranja
                const corFinal = '80,80,80';     // Cinza
                criar(
                    cx + (Math.random() - 0.5) * j.largura,
                    cy + j.raio / 2,
                    corInicial,
                    Math.random() * 4 + 2, // tamanho
                    60,                    // duração
                    (Math.random() - 0.5) * 1, // vx
                    -Math.random() * 1,    // vy
                    corFinal               // corFinal para transição
                );
            }
        }
    },
    'matrix_glitch': {
        nome: "Matrix Glitch", emoji: "📟",
        update: (ctx, cx, cy, p, gs, j) => {
            if (Math.random() > 0.9) {
                p.opacidade = Math.random() * 0.5 + 0.5;
                const offsetX = (Math.random() - 0.5) * 20;
                ctx.shadowColor = '#0F0';
                ctx.shadowBlur = 15;
                if (Math.random() > 0.95) {
                    ctx.fillStyle = `rgba(0, 255, 0, ${Math.random() * 0.2})`;
                    ctx.fillRect(0, Math.random() * canvas.height, canvas.width, Math.random() * 2);
                }
            }
        }
    },
    'matrix_code_rain': {
        nome: "Matrix Code Rain", emoji: "🔢",
        update: (ctx, cx, cy, p, gs, j) => {
            if (gs.framesDesdeInicio % 2 === 0) {
                particulas.push({
                    x: Math.random() * canvas.width,
                    y: 0,
                    duracao: 120,
                    vida: 120,
                    texto: String.fromCharCode(0x30A0 + Math.random() * 96),
                    vy: 5,
                    cor: '#00ff00'
                });
            }
        }
    },
    'matrix_loop': {
        nome: "Matrix Loop", emoji: "🔄",
        orbital: (ctx, cx, cy, p, gs, char, cor, vel, raio, preencher = false, tamanho = 20) => {
            const angulo = gs.framesDesdeInicio * vel;
            const x = cx + Math.cos(angulo) * raio;
            const y = cy + Math.sin(angulo) * raio;
            ctx.font = `${tamanho}px monospace`;
            if (preencher) {
                ctx.fillStyle = cor;
            } else {
                ctx.strokeStyle = cor;
            }
            ctx.strokeText(char, x, y);
        },
        update: (ctx, cx, cy, p, gs) => {
            EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '0', '#00FF00', 0.1, 25);
            EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '1', '#33FF33', -0.08, 35);
        }
    },
    'loop_key': { nome: "Key Loop", emoji: "🔑", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔑', '#FFFF00', 0.1, 30, true, 20) },
    'loop_lock': { nome: "Lock Loop", emoji: "🔒", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔒', '#C0C0C0', -0.07, 35) },
    'loop_bomb': { nome: "Bomb Loop", emoji: "💣", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '💣', '#8B0000', 0.15, 22) },
    'loop_ghost': { nome: "Ghost Loop", emoji: "👻", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '👻', '#E6E6FA', 0.08, 40, true, 25) },
    'loop_skull': { nome: "Skull Loop", emoji: "💀", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '💀', '#FFFFFF', -0.1, 33) },
    'loop_alien': { nome: "Alien Loop", emoji: "👽", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '👽', '#98FB98', 0.11, 28) },
    'loop_robot': { nome: "Robot Loop", emoji: "🤖", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🤖', '#B0C4DE', -0.09, 38) },
    'loop_crown': { nome: "Crown Loop", emoji: "👑", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '👑', '#FFD700', 0.06, 45, true, 30) },
    'loop_gem': { nome: "Gem Loop", emoji: "💎", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '💎', '#00FFFF', 0.13, 26) },
    'loop_bell': {
        nome: "Bell Loop", emoji: "🔔", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔔', '#FFD700', 0.12, 27)
    },
    'loop_magnet': { nome: "Magnet Loop", emoji: "🧲", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🧲', '#B22222', 0.1, 30, true, 30) },
    'loop_battery': { nome: "Battery Loop", emoji: "🔋", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔋', '#7CFC00', 0.07, 39) },
    'loop_wrench': { nome: "Wrench Loop", emoji: "🔧", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔧', '#A9A9A9', 0.09, 31) },
    'loop_compass': { nome: "Compass Loop", emoji: "🧭", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🧭', '#DEB887', 0.05, 42) },
    'loop_joystick': { nome: "Joystick Loop", emoji: "🕹️", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🕹️', '#DC143C', 0.14, 23) },
    'loop_crystal_ball': { nome: "Crystal Ball Loop", emoji: "🔮", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔮', '#BA55D3', 0.08, 35) },
    'loop_telescope': { nome: "Telescope Loop", emoji: "🔭", update: (ctx, cx, cy, p, gs) => EFEITOS.matrix_loop.orbital(ctx, cx, cy, p, gs, '🔭', '#4682B4', 0.06, 40, true, 25) },
    'matrix_packet': {
        nome: "Matrix Packet", emoji: "📦",
        update: (ctx, cx, cy, p, gs, j, criar) => {
            if (gs.framesDesdeInicio % 20 === 0) {
                criar(j.x - 20, j.y, '200,200,255', 5, 50, 4, 0);
                criar(j.x + j.largura + 20, j.y, '200,200,255', 5, 50, -4, 0);
            }
        }
    },
    'matrix_sentinel': {
        nome: "Matrix Sentinel", emoji: "🦑",
        update: (ctx, cx, cy, p, gs, j) => {
            if (Math.random() > 0.95) {
                ctx.strokeStyle = 'rgba(255, 0, 0, 0.8)';
                ctx.lineWidth = 1;
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(Math.random() * canvas.width, Math.random() * canvas.height);
                ctx.stroke();
            }
        }
    },
    'matrix_oracle': {
        nome: "Matrix Oracle", emoji: "🔮",
        update: (ctx, cx, cy, p, gs) => {
            const radius = 15 + Math.sin(gs.framesDesdeInicio * 0.05) * 5;
            const grad = ctx.createRadialGradient(cx, cy, 1, cx, cy, radius);
            grad.addColorStop(0, 'rgba(200, 200, 255, 0.8)');
            grad.addColorStop(1, 'rgba(0, 255, 0, 0)');
            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.arc(cx, cy, radius, 0, Math.PI * 2);
            ctx.fill();
        }
    },
    'matrix_white_rabbit': {
        nome: "Matrix White Rabbit", emoji: "🐇",
        update: (ctx, cx, cy, p, gs, j) => {
            if (gs.framesDesdeInicio % 60 === 0) {
                particulas.push({ x: j.x, y: j.y - 30, duracao: 55, vida: 55, texto: '🐇', vy: -1.5 });
            }
        }
    },
    'matrix_agent': {
        nome: "Matrix Agent", emoji: "🕶️",
        update: (ctx, cx, cy, p, gs, j) => {
            p.cor = '#1A1A1A'; // Cor escura
            p.opacidade = 0.95;
            ctx.shadowBlur = 10;
            ctx.shadowColor = '#FFFFFF';
        }
    },
    'rastro luminoso': {
        nome: "Rastro Luminoso", emoji: "💫",
        update: (ctx, cx, cy, personagem) => {
            ctx.shadowBlur = 15;
            ctx.shadowColor = personagem.cor;
        }
    },
    'bolhas': {
        nome: "Bolhas", emoji: "🧼",
        update: (ctx, cx, cy, personagem, gameState, jogador, criarParticula) => {
            if (gameState.framesDesdeInicio % 10 === 0) {
                criarParticula(cx + (Math.random() - 0.5) * jogador.largura, cy + jogador.raio, '255, 255, 255', Math.random() * 4 + 2, 50, (Math.random() - 0.5) * 0.2, -Math.random() * 1.5 - 0.5);
            }
        }
    },
    'elétrico': {
        nome: "Elétrico", emoji: "⚡",
        update: (ctx, cx, cy) => {
            if (Math.random() > 0.95) {
                ctx.strokeStyle = `rgba(255, 255, 0, ${Math.random() * 0.7 + 0.3})`;
                ctx.lineWidth = Math.random() * 3 + 1;
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                for (let i = 0; i < 4; i++) {
                    ctx.lineTo(cx + (Math.random() - 0.5) * 60, cy + (Math.random() - 0.5) * 60);
                }
                ctx.stroke();
            }
        }
    },
    'fogo': {
        nome: "Fogo", emoji: "🔥",
        update: (ctx, cx, cy, personagem, gameState, jogador, criarParticula) => {
            if (gameState.framesDesdeInicio % 3 === 0) {
                const cor = Math.random() > 0.5 ? '255, 87, 34' : '255, 193, 7';
                criarParticula(cx, cy + jogador.raio / 2, cor, Math.random() * 5 + 3, 30, (Math.random() - 0.5) * 1, -Math.random() * 1.5);
            }
        }
    },
    'gelo': {
        nome: "Gelo", emoji: "❄️",
        update: (ctx, cx, cy, personagem, gameState, jogador, criarParticula) => {
            if (gameState.framesDesdeInicio % 4 === 0) {
                criarParticula(cx + (Math.random() - 0.5) * jogador.largura, cy + (Math.random() - 0.5) * jogador.altura, '200, 225, 255', Math.random() * 2 + 1, 40, 0, 0);
            }
        }
    },
    'glitch': {
        nome: "Glitch", emoji: "💥",
        update: (ctx, cx, cy, personagem, gameState, jogador) => {
            if (Math.random() > 0.9) {
                const offsetX = (Math.random() - 0.5) * 15;
                const offsetY = (Math.random() - 0.5) * 15;
                ctx.drawImage(canvas, jogador.x, jogador.y, jogador.largura, jogador.altura, jogador.x + offsetX, jogador.y + offsetY, jogador.largura, jogador.altura);
            }
        }
    },
    'sombra': {
        nome: "Sombra", emoji: "🌑",
        update: (ctx) => {
            ctx.shadowOffsetX = 10;
            ctx.shadowOffsetY = 10;
            ctx.shadowColor = 'rgba(0,0,0,0.4)';
            ctx.shadowBlur = 5;
        }
    },
    'arco-íris': {
        nome: "Arco-íris", emoji: "🌈",
        update: (ctx, cx, cy, personagem, gameState) => {
            personagem.cor = `hsl(${gameState.framesDesdeInicio % 360}, 100%, 70%)`;
        }
    },
    'holograma': {
        nome: "Holograma", emoji: "🌐",
        update: (ctx, cx, cy, personagem, gameState, jogador) => {
            personagem.opacidade = 0.7;
            ctx.strokeStyle = `hsla(${gameState.framesDesdeInicio % 360}, 100%, 80%, 0.7)`;
            ctx.lineWidth = 2;
            ctx.strokeRect(jogador.x - 5, jogador.y - 5, jogador.largura + 10, jogador.altura + 10);
            if (Math.random() > 0.8) {
                ctx.fillStyle = `hsla(${gameState.framesDesdeInicio % 360}, 100%, 80%, 0.1)`;
                ctx.fillRect(0, Math.random() * canvas.height, canvas.width, Math.random() * 5);
            }
        }
    },
    'psicodélico': {
        nome: "Psicodélico", emoji: "🌀",
        update: (ctx, cx, cy, personagem, gameState) => {
            const r = Math.sin(gameState.framesDesdeInicio * 0.1) * 127 + 128;
            const g = Math.sin(gameState.framesDesdeInicio * 0.1 + 2) * 127 + 128;
            const b = Math.sin(gameState.framesDesdeInicio * 0.1 + 4) * 127 + 128;
            personagem.cor = `rgb(${r},${g},${b})`;
            ctx.shadowBlur = 20;
            ctx.shadowColor = `rgb(${g},${b},${r})`;
        }
    },
    'coração': {
        nome: "Coração", emoji: "💖",
        update: (ctx, cx, cy, personagem, gameState, jogador, criarParticula) => {
            if (gameState.framesDesdeInicio % 15 === 0) {
                criarParticula(cx, cy, '255, 105, 180', 10, 50, (Math.random() - 0.5) * 1, -Math.random() * 1);
            }
        }
    },
    'musical': {
        nome: "Musical", emoji: "🎶",
        update: (ctx, cx, cy, personagem, gameState) => {
            if (gameState.framesDesdeInicio % 20 === 0) {
                const nota = ['🎵', '🎶', '🎼'][Math.floor(Math.random() * 3)];
                particulas.push({ x: cx, y: cy, duracao: 30, vida: 30, texto: nota, vy: -2 });
            }
        }
    },
    'cósmico': {
        nome: "Cósmico", emoji: "🌌",
        update: (ctx, cx, cy, personagem, gameState) => {
            ctx.shadowBlur = 25;
            ctx.shadowColor = `hsl(${(gameState.framesDesdeInicio + 180) % 360}, 100%, 70%)`;
        }
    },
    'matrix': {
        nome: "Matrix", emoji: "💻",
        update: (ctx, cx, cy, personagem, gameState, jogador) => {
            if (gameState.framesDesdeInicio % 4 === 0) {
                particulas.push({ x: cx + (Math.random() - 0.5) * jogador.largura, y: cy, duracao: 60, vida: 60, texto: String.fromCharCode(0x30A0 + Math.random() * 96), vy: 2, cor: '#00ff00' });
            }
        }
    },
    'nuvem': {
        nome: "Nuvem", emoji: "☁️",
        update: (ctx, cx, cy, personagem, gameState, jogador, criarParticula) => {
            personagem.opacidade = 0.8;
            if (gameState.framesDesdeInicio % 8 === 0) {
                criarParticula(cx, cy + jogador.altura / 2, '255, 255, 255', 15, 60, (Math.random() - 0.5) * 0.5, 0);
            }
        }
    },
    'tóxico': {
        nome: "Tóxico", emoji: "☣️",
        update: (ctx, cx, cy, personagem, gameState, jogador, criarParticula) => {
            if (gameState.framesDesdeInicio % 10 === 0) {
                criarParticula(cx, cy + jogador.raio, '173, 255, 47', 8, 50, (Math.random() - 0.5) * 0.3, -Math.random() * 1);
            }
        }
    },
    'estático': {
        nome: "Estático", emoji: "📺",
        update: (ctx, cx, cy, personagem, gameState, jogador) => {
            if (Math.random() > 0.5) {
                personagem.opacidade = 0.7;
                ctx.fillStyle = `rgba(255, 255, 255, ${Math.random() * 0.2})`;
                ctx.fillRect(jogador.x + (Math.random() - 0.5) * 10, jogador.y + (Math.random() - 0.5) * 10, jogador.largura, jogador.altura);
            }
        }
    }
};
